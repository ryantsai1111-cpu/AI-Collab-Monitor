param([ValidateSet('start','finish')][string]$Phase)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$utf8 = [Text.UTF8Encoding]::new($false)
$unicodeName = [string][char]0x4E2D + [char]0x6587
$scratch = Join-Path $PSScriptRoot ('portable monitor ' + $unicodeName + ' path')
$source = Join-Path $PSScriptRoot 'monitor-build'
$psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$actors = @('claude','dot','codex','timeline')
function Save([string]$Name, $Data) { [IO.File]::WriteAllText((Join-Path $scratch $Name),($Data | ConvertTo-Json -Depth 8),$utf8) }
if ($Phase -eq 'start') {
    if (Test-Path -LiteralPath $scratch) { throw 'Scratch exists; refusing overwrite.' }
    [void][IO.Directory]::CreateDirectory($scratch)
    [void][IO.Directory]::CreateDirectory((Join-Path $scratch 'helpers'))
    foreach ($name in @('start-monitor.ps1','stop-monitor.ps1','reset-monitor.ps1','AI-Collab-Monitor.bat','README.md','helpers\common.ps1','helpers\watch-pane.ps1')) {
        [IO.File]::Copy((Join-Path $source $name),(Join-Path $scratch $name),$false)
    }
    # This launch verifies the shipped batch file from a path with spaces and Unicode.
    $launcher = Start-Process -FilePath (Join-Path $scratch 'AI-Collab-Monitor.bat') -WorkingDirectory $scratch -WindowStyle Hidden -PassThru
    if (-not $launcher.WaitForExit(30000)) { throw 'Batch launcher did not finish in 30 seconds; no retry.' }
    Save 'batch-result.json' @{ExitCode=$launcher.ExitCode; Root=$scratch; Utc=[DateTime]::UtcNow.ToString('o')}
    if ($launcher.ExitCode -ne 0) { throw 'Portable batch launch failed.' }
    foreach ($actor in $actors) {
        [IO.File]::AppendAllText((Join-Path $scratch ('logs\' + $actor + '.log')),('PORTABLE ACCEPTANCE ' + $actor + ' ' + $unicodeName + "`r`n"),$utf8)
    }
    Write-Output "Batch launched from $scratch with exit code $($launcher.ExitCode)."
}
if ($Phase -eq 'finish') {
    Add-Type -AssemblyName UIAutomationClient
    Add-Type -AssemblyName UIAutomationTypes
    $desktop = [System.Windows.Automation.AutomationElement]::RootElement
    $windows = @($desktop.FindAll([System.Windows.Automation.TreeScope]::Children,[System.Windows.Automation.Condition]::TrueCondition) | Where-Object { $_.Current.Name -like 'AI-Collab-Monitor*' })
    if ($windows.Count -ne 1) { throw 'Expected one isolated portable test window.' }
    $window = $windows[0]
    $windowId = $window.Current.NativeWindowHandle
    $windowPid = $window.Current.ProcessId
    $paneText = @()
    foreach ($el in $window.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition)) {
        $pattern = $null
        if ($el.TryGetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern,[ref]$pattern)) {
            $value = $pattern.DocumentRange.GetText(-1)
            if ($value -like '*PORTABLE ACCEPTANCE*') { $paneText += @{Name=$el.Current.Name; Text=$value; Offscreen=$el.Current.IsOffscreen} }
        }
    }
    $passed = $paneText.Count -eq 4
    foreach ($actor in $actors) {
        if (-not @($paneText | Where-Object { $_.Text -like ('*PORTABLE ACCEPTANCE ' + $actor + ' ' + $unicodeName + '*') }).Count) { $passed=$false }
    }
    Save 'portable-uia.json' @{FourPaneTexts=$paneText; Passed=$passed; Utc=[DateTime]::UtcNow.ToString('o')}
    $stopOutput = & $psExe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $scratch 'stop-monitor.ps1') 2>&1
    $stopCode = $LASTEXITCODE
    Save 'portable-stop.json' @{ExitCode=$stopCode; Output=($stopOutput | Out-String)}
    if ($stopCode -ne 0) { throw 'Portable stop failed; no UI close attempted.' }
    Start-Sleep -Milliseconds 400
    $remaining = @($desktop.FindAll([System.Windows.Automation.TreeScope]::Children,[System.Windows.Automation.Condition]::TrueCondition) | Where-Object { $_.Current.NativeWindowHandle -eq $windowId -and $_.Current.ProcessId -eq $windowPid -and $_.Current.Name -like 'AI-Collab-Monitor*' })
    if ($remaining.Count -eq 1) { $remaining[0].GetCurrentPattern([System.Windows.Automation.WindowPattern]::Pattern).Close() }
    $result = @{Root=$scratch; BatchLaunchExitCode=(Get-Content -LiteralPath (Join-Path $scratch 'batch-result.json') -Raw | ConvertFrom-Json).ExitCode; FourPanesVerified=$passed; StopExitCode=$stopCode; ClosedOnlyOwnedWindow=$windowId}
    Save 'portable-summary.json' $result
    $result | ConvertTo-Json
    if (-not $passed) { throw 'Portable UI content did not pass.' }
}
