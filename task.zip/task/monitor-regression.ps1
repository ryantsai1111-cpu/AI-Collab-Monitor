param()
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$workspace = $PSScriptRoot
$chineseName = [string][char]0x6E2C + [char]0x8A66
$scratch = Join-Path $workspace ('monitor regression ' + $chineseName + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0,8))
$source = Join-Path $workspace 'monitor-build'
$utf8 = [Text.UTF8Encoding]::new($false)
$shell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$result = [ordered]@{ StartedUtc=[DateTime]::UtcNow.ToString('o'); PowerShellVersion=$PSVersionTable.PSVersion.ToString(); Scratch=$scratch; Tests=@(); Invocations=@(); Passed=$false }
$reader = $null
$invocationNumber = 0
[void][IO.Directory]::CreateDirectory($scratch)
$evidenceDir = Join-Path $scratch 'evidence'
[void][IO.Directory]::CreateDirectory($evidenceDir)
$report = Join-Path $evidenceDir 'regression-results.json'

function Check([string]$Name, [bool]$Condition, $Details) {
    $result.Tests += [ordered]@{ Name=$Name; Passed=$Condition; Details=$Details }
    if (-not $Condition) { throw ('Check failed: ' + $Name) }
}

function Launch([string]$Script, [string[]]$Extra=@(), [switch]$Wait) {
    $script:invocationNumber++
    $tag = '{0:D2}-{1}' -f $script:invocationNumber, [IO.Path]::GetFileNameWithoutExtension($Script)
    $stdout = Join-Path $evidenceDir ($tag + '.stdout.txt')
    $stderr = Join-Path $evidenceDir ($tag + '.stderr.txt')
    $parts = @('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$Script) + $Extra
    $arguments = ($parts | ForEach-Object { '"' + $_ + '"' }) -join ' '
    $p = Start-Process -FilePath $shell -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
    # Cache the native handle before exit; PS5.1 otherwise can expose a null ExitCode.
    $null = $p.Handle
    if ($Wait) {
        if (-not $p.WaitForExit(15000)) { throw ('Timed out without killing process: ' + $tag) }
        $p.WaitForExit()
    }
    $record = [ordered]@{ Tag=$tag; Script=$Script; Stdout=$stdout; Stderr=$stderr; Pid=$p.Id; ExitCode=$null }
    if ($Wait) { $record.ExitCode=$p.ExitCode }
    $result.Invocations += $record
    return [pscustomobject]@{ Process=$p; Stdout=$stdout; Stderr=$stderr; Record=$record }
}

function Read-Shared([string]$Path) {
    if (-not [IO.File]::Exists($Path)) { return '' }
    $stream = [IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
    try {
        $read = [IO.StreamReader]::new($stream, $utf8)
        try { return $read.ReadToEnd() } finally { $read.Dispose() }
    } finally { $stream.Dispose() }
}

function Append-Bytes([string]$Path, [byte[]]$Data) {
    $stream = [IO.File]::Open($Path,[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::ReadWrite)
    try { $stream.Write($Data,0,$Data.Length); $stream.Flush() } finally { $stream.Dispose() }
}

function Wait-Output([string]$Path, [string]$Expected, [Diagnostics.Process]$Process) {
    $deadline = [DateTime]::UtcNow.AddSeconds(10)
    do {
        if ((Read-Shared $Path).Contains($Expected)) { return $true }
        $Process.Refresh()
        if ($Process.HasExited) { return $false }
        Start-Sleep -Milliseconds 100
    } while ([DateTime]::UtcNow -lt $deadline)
    return $false
}

try {
    Check 'Actual Windows PowerShell 5.1' ($PSVersionTable.PSVersion.Major -eq 5 -and $PSVersionTable.PSVersion.Minor -eq 1) $PSVersionTable.PSVersion.ToString()
    foreach ($dir in @('helpers','logs','archive','tasks','.monitor\sessions')) { [void][IO.Directory]::CreateDirectory((Join-Path $scratch $dir)) }
    foreach ($file in @('start-monitor.ps1','stop-monitor.ps1','reset-monitor.ps1','helpers\common.ps1','helpers\watch-pane.ps1')) {
        [IO.File]::Copy((Join-Path $source $file),(Join-Path $scratch $file),$false)
    }
    $actors = @('claude','dot','codex','timeline')
    foreach ($actor in $actors) { [IO.File]::WriteAllBytes((Join-Path $scratch ('logs\' + $actor + '.log')),[byte[]]@()) }
    $taskFile = Join-Path $scratch 'tasks\preserve-me.txt'
    [IO.File]::WriteAllText($taskFile,'TASK SENTINEL - must remain unchanged',$utf8)
    $taskHash = (Get-FileHash -LiteralPath $taskFile -Algorithm SHA256).Hash
    $scriptHashes = @{}
    Get-ChildItem -LiteralPath $scratch -Recurse -Filter '*.ps1' -File | ForEach-Object { $scriptHashes[$_.FullName]=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash }

    $pendingId = [Guid]::NewGuid().ToString('N')
    $pendingPath = Join-Path $scratch ('.monitor\sessions\' + $pendingId)
    [void][IO.Directory]::CreateDirectory($pendingPath)
    [IO.File]::WriteAllText((Join-Path $pendingPath 'session.json'),'{}',$utf8)
    $blocked = Launch (Join-Path $scratch 'reset-monitor.ps1') -Wait
    Check 'Pending session blocks reset' ($blocked.Process.ExitCode -eq 1 -and ([regex]::Replace((Read-Shared $blocked.Stderr),'\s','')).Contains('Resetrefused')) @{ ExitCode=$blocked.Process.ExitCode; Stderr=$blocked.Stderr }
    Check 'Blocked reset leaves empty logs and tasks untouched' ((@(Get-ChildItem -LiteralPath (Join-Path $scratch 'logs') -File | Where-Object Length -ne 0).Count -eq 0) -and (Get-FileHash -LiteralPath $taskFile -Algorithm SHA256).Hash -eq $taskHash) $taskHash
    $cancel = Launch (Join-Path $scratch 'stop-monitor.ps1') -Wait
    Check 'Stop cancels pending session without processes' ($cancel.Process.ExitCode -eq 0 -and (Test-Path -LiteralPath (Join-Path $pendingPath 'stop.signal'))) @{ ExitCode=$cancel.Process.ExitCode; Session=$pendingId }

    $liveId = [Guid]::NewGuid().ToString('N')
    $livePath = Join-Path $scratch ('.monitor\sessions\' + $liveId)
    [void][IO.Directory]::CreateDirectory($livePath)
    [IO.File]::WriteAllText((Join-Path $livePath 'session.json'),'{}',$utf8)
    $reader = Launch (Join-Path $scratch 'helpers\watch-pane.ps1') @('-SessionId',$liveId,'-Actor','claude')
    Check 'Headless native reader starts from spaced Unicode path' (Wait-Output $reader.Stdout 'CLAUDE - PRIMARY REVIEWER' $reader.Process) @{ Path=$scratch; Stdout=$reader.Stdout }
    $liveReset = Launch (Join-Path $scratch 'reset-monitor.ps1') -Wait
    Check 'Active reader blocks reset' ($liveReset.Process.ExitCode -eq 1 -and ([regex]::Replace((Read-Shared $liveReset.Stderr),'\s','')).Contains('Resetrefused')) @{ ExitCode=$liveReset.Process.ExitCode }

    $logPath = Join-Path $scratch 'logs\claude.log'
    $prefix = '[UTF8-SPLIT-FIRST]'
    $prefix += 'A' * (8189 - $prefix.Length)
    $firstBytes = New-Object byte[] 8192
    [Array]::Copy($utf8.GetBytes($prefix),0,$firstBytes,0,8189)
    $firstBytes[8189]=0xF0; $firstBytes[8190]=0x9F; $firstBytes[8191]=0x98
    Append-Bytes $logPath $firstBytes
    Check 'Reader consumes 8192-byte chunk ending with incomplete emoji' (Wait-Output $reader.Stdout $prefix $reader.Process) @{ InputBytes=8192; IncompleteEmojiBytes='F0 9F 98'; DecodedPrefixChars=$prefix.Length }
    $secondBytes = New-Object byte[] 8192
    $secondBytes[0]=0x80
    for ($i=1; $i -lt $secondBytes.Length; $i++) { $secondBytes[$i]=66 }
    Append-Bytes $logPath $secondBytes
    $emoji = [char]::ConvertFromUtf32(0x1F600)
    $unicode = [string][char]0x4E2D + [char]0x6587 + [char]0x6E2C + [char]0x8A66
    $lastText = "`r`nUNICODE " + $unicode + ' ' + $emoji + "`r`nUTF8_COMPLETE`r`n"
    Append-Bytes $logPath ($utf8.GetBytes($lastText))
    Check 'Reader displays subsequent Unicode append' (Wait-Output $reader.Stdout 'UTF8_COMPLETE' $reader.Process) @{ Unicode=$unicode; Emoji=$emoji }
    $expectedText = $prefix + $emoji + ('B' * 8191) + $lastText
    Check 'Exact Unicode payload survives decoder boundary' ((Read-Shared $reader.Stdout).Contains($expectedText)) @{ PayloadChars=$expectedText.Length; FirstReadBytes=8192; SecondReadBytes=8192 }

    $stopped = Launch (Join-Path $scratch 'stop-monitor.ps1') -Wait
    $exited = $reader.Process.WaitForExit(10000)
    if ($exited) { $reader.Process.WaitForExit(); $reader.Record.ExitCode=$reader.Process.ExitCode }
    $readerText = Read-Shared $reader.Stdout
    Check 'Idle reader cooperatively stops with exit 0' ($stopped.Process.ExitCode -eq 0 -and $exited -and $reader.Process.ExitCode -eq 0 -and $readerText.Contains('[MONITOR STOPPED]')) @{ StopExit=$stopped.Process.ExitCode; ReaderExit=$reader.Record.ExitCode; StopSignal=(Test-Path -LiteralPath (Join-Path $livePath 'stop.signal')) }
    Check 'No reader error or replacement characters' (-not $readerText.Contains('[MONITOR ERROR]') -and -not $readerText.Contains([string][char]0xFFFD) -and (Read-Shared $reader.Stderr).Length -eq 0) @{ Stdout=$reader.Stdout; Stderr=$reader.Stderr }

    $oldLogHashes = @{}
    foreach ($actor in $actors) {
        $path = Join-Path $scratch ('logs\' + $actor + '.log')
        [IO.File]::AppendAllText($path,($actor + " archive preservation`r`n"),$utf8)
        $oldLogHashes[$actor]=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
    }
    # Reserve nearby second-resolution names to exercise a real existing-directory collision.
    $collisionPaths = @()
    $collisionTime = Get-Date
    foreach ($offset in 0..8) {
        $collisionPath = Join-Path $scratch ('archive\' + $collisionTime.AddSeconds($offset).ToString('yyyyMMdd-HHmmss'))
        [void][IO.Directory]::CreateDirectory($collisionPath)
        [IO.File]::WriteAllText((Join-Path $collisionPath 'existing-marker.txt'),'PRESERVE EXISTING ARCHIVE',$utf8)
        $collisionPaths += $collisionPath
    }
    $reset = Launch (Join-Path $scratch 'reset-monitor.ps1') -Wait
    Check 'Stopped sessions permit reset' ($reset.Process.ExitCode -eq 0) @{ ExitCode=$reset.Process.ExitCode; Stdout=$reset.Stdout }
    $archives = @(Get-ChildItem -LiteralPath (Join-Path $scratch 'archive') -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'claude.log') })
    Check 'Archive collision uses fresh suffixed directory' ($archives.Count -eq 1 -and $archives[0].Name -match '^\d{8}-\d{6}-\d{2}$') @($archives.FullName)
    $archivedHashes = @{}
    foreach ($actor in $actors) { $archivedHashes[$actor]=(Get-FileHash -LiteralPath (Join-Path $archives[0].FullName ($actor + '.log')) -Algorithm SHA256).Hash }
    $hashMatches = @($actors | Where-Object { $archivedHashes[$_] -ne $oldLogHashes[$_] }).Count -eq 0
    Check 'All four archived logs preserve exact bytes' $hashMatches @{ Original=$oldLogHashes; Archived=$archivedHashes }
    Check 'Reset produces four empty replacement logs' ((@(Get-ChildItem -LiteralPath (Join-Path $scratch 'logs') -File).Count -eq 4) -and (@(Get-ChildItem -LiteralPath (Join-Path $scratch 'logs') -File | Where-Object Length -ne 0).Count -eq 0)) $true
    $preservedCollisions = @($collisionPaths | Where-Object { [IO.File]::ReadAllText((Join-Path $_ 'existing-marker.txt')) -ne 'PRESERVE EXISTING ARCHIVE' }).Count -eq 0
    Check 'Pre-existing archive markers retained' $preservedCollisions $collisionPaths
    $resetAgain = Launch (Join-Path $scratch 'reset-monitor.ps1') -Wait
    $archivesAgain = @(Get-ChildItem -LiteralPath (Join-Path $scratch 'archive') -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'claude.log') })
    Check 'Repeated reset keeps both archives' ($resetAgain.Process.ExitCode -eq 0 -and $archivesAgain.Count -eq 2 -and (Test-Path -LiteralPath $archives[0].FullName)) @($archivesAgain.FullName)
    $scriptsPreserved = @($scriptHashes.Keys | Where-Object { (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash -ne $scriptHashes[$_] }).Count -eq 0
    Check 'Tasks and scripts remain unchanged' ((Get-FileHash -LiteralPath $taskFile -Algorithm SHA256).Hash -eq $taskHash -and $scriptsPreserved) @{ TasksSHA256=$taskHash; ScriptHashes=$scriptHashes }
    $result.Passed=$true
} catch {
    $result.Error=$_.Exception.ToString()
} finally {
    # Only cooperative cancellation of this scratch monitor's own sessions; no kills.
    $sessionRoot = Join-Path $scratch '.monitor\sessions'
    if (Test-Path -LiteralPath $sessionRoot) {
        foreach ($session in Get-ChildItem -LiteralPath $sessionRoot -Directory) {
            $signal = Join-Path $session.FullName 'stop.signal'
            if (-not (Test-Path -LiteralPath $signal)) { [IO.File]::WriteAllBytes($signal,[byte[]]@()) }
        }
    }
    if ($reader -and -not $reader.Process.HasExited) { [void]$reader.Process.WaitForExit(10000) }
    $result.CompletedUtc=[DateTime]::UtcNow.ToString('o')
    [IO.File]::WriteAllText($report,($result | ConvertTo-Json -Depth 10),$utf8)
    Write-Output ('Evidence: ' + $report)
    Write-Output ('Passed: ' + $result.Passed)
    Write-Output ('Tests: ' + $result.Tests.Count)
}
if (-not $result.Passed) { exit 1 }
