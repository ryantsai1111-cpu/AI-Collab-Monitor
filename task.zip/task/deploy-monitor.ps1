$ErrorActionPreference = 'Stop'
$source = Join-Path $PSScriptRoot 'monitor-build'
$target = 'C:\Users\ryant\Desktop\AI-Collab-Monitor'
$targetExisted = Test-Path -LiteralPath $target
if ($targetExisted) {
    if (-not (Test-Path -LiteralPath $target -PathType Container)) { throw 'Target exists as a file; nothing was changed.' }
    $target = Join-Path $target ('v0.1-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0,8))
}
if (Test-Path -LiteralPath $target) { throw 'New target is not empty; refusing overwrite.' }
[void][IO.Directory]::CreateDirectory($target)
foreach ($sub in @('logs','archive','tasks','helpers','evidence')) { [void][IO.Directory]::CreateDirectory((Join-Path $target $sub)) }
foreach ($name in @('start-monitor.ps1','stop-monitor.ps1','reset-monitor.ps1','AI-Collab-Monitor.bat','README.md','helpers\common.ps1','helpers\watch-pane.ps1')) {
    [IO.File]::Copy((Join-Path $source $name),(Join-Path $target $name),$false)
}
foreach ($name in @('claude','dot','codex','timeline')) {
    $handle = [IO.File]::Open((Join-Path $target ('logs\' + $name + '.log')),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    $handle.Dispose()
}
[IO.File]::Copy((Join-Path $PSScriptRoot 'wt-local-help.txt'),(Join-Path $target 'evidence\wt-local-help.txt'),$false)
$record = [ordered]@{ ActualPath=$target; OriginalTargetExisted=$targetExisted; Computer=$env:COMPUTERNAME; CreatedUtc=[DateTime]::UtcNow.ToString('o'); WindowsTerminalVersion='1.24.12741.0' }
$json = $record | ConvertTo-Json
[IO.File]::WriteAllText((Join-Path $target 'evidence\deployment.json'),$json,[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'deployment.json'),$json,[Text.UTF8Encoding]::new($false))
$json
