param([ValidateSet('start','observe','finish')][string]$Phase)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$deployment = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'deployment.json') -Raw | ConvertFrom-Json
$target = $deployment.ActualPath
$evidence = Join-Path $target 'evidence'
$psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$utf8 = [Text.UTF8Encoding]::new($false)
$actors = @('claude','dot','codex','timeline')
function Save-Json([string]$Name, $Data) {
    [IO.File]::WriteAllText((Join-Path $evidence $Name),($Data | ConvertTo-Json -Depth 8),$utf8)
}
function Invoke-MonitorScript([string]$Name, [string]$EvidenceName) {
    $output = & $psExe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $target $Name) 2>&1
    $code = $LASTEXITCODE
    $record = [ordered]@{Script=$Name; ExitCode=$code; Utc=[DateTime]::UtcNow.ToString('o'); Output=($output | Out-String)}
    Save-Json $EvidenceName $record
    Write-Output ($record | ConvertTo-Json)
}
function Get-ScopedProcessSnapshot {
    @(Get-Process | Where-Object { $_.ProcessName -in @('claude','codex','WindowsTerminal','OpenConsole','powershell','pwsh') } | ForEach-Object {
        $started = $null
        try { $started = $_.StartTime.ToUniversalTime().ToString('o') } catch {}
        [pscustomobject]@{Name=$_.ProcessName; Pid=$_.Id; StartedUtc=$started; SessionId=$_.SessionId}
    })
}
if ($Phase -eq 'start') {
    Save-Json 'processes-before.json' (Get-ScopedProcessSnapshot)
    # A harmless task sentinel proves reset preserves task bytes.
    $sentinel = Join-Path $target 'tasks\acceptance-sentinel.txt'
    if (Test-Path -LiteralPath $sentinel) { throw 'Acceptance sentinel already exists; no overwrite.' }
    [IO.File]::WriteAllText($sentinel,'Acceptance only. Must survive reset unchanged.',$utf8)
    Save-Json 'task-before.json' ([ordered]@{Path=$sentinel; Hash=(Get-FileHash -LiteralPath $sentinel -Algorithm SHA256).Hash})
    Invoke-MonitorScript 'start-monitor.ps1' 'start-result.json'
    if ((Get-Content -LiteralPath (Join-Path $evidence 'start-result.json') -Raw | ConvertFrom-Json).ExitCode -ne 0) { throw 'Start failed; inspect output before proceeding.' }
    Invoke-MonitorScript 'start-monitor.ps1' 'duplicate-start-result.json'
    Invoke-MonitorScript 'reset-monitor.ps1' 'active-reset-result.json'
    $marker = 'ACCEPTANCE-' + [Guid]::NewGuid().ToString('N').Substring(0,12)
    $appends = @()
    foreach ($actor in $actors) {
        $label = $actor.Substring(0,1).ToUpperInvariant() + $actor.Substring(1)
        if ($actor -eq 'timeline') {
            $line = [DateTimeOffset]::Now.ToString('o') + ' | TASK-ACCEPTANCE | MONITOR_TEST | PANE_TEST | Timeline pane test ' + $marker + "`r`n"
        } else {
            $line = '[MONITOR ACCEPTANCE TEST - NOT AGENT OUTPUT]' + "`r`n" + $label + ' pane test ' + $marker + "`r`n"
        }
        [IO.File]::AppendAllText((Join-Path $target ('logs\' + $actor + '.log')),$line,$utf8)
        $appends += [pscustomobject]@{Actor=$actor; Text=$line; AppendedUtc=[DateTime]::UtcNow.ToString('o')}
    }
    # Verify incremental Unicode and paths containing spaces in the normal launch as well.
    $unicode = [string][char]0x4E2D + [char]0x6587 + ' ' + [char]::ConvertFromUtf32(0x1F642)
    [IO.File]::AppendAllText((Join-Path $target 'logs\codex.log'),('UTF8 test: ' + $unicode + "`r`n"),$utf8)
    Save-Json 'appends.json' ([ordered]@{Marker=$marker; Unicode=$unicode; Appends=$appends})
    Write-Output "Appended four live pane tests: $marker"
}
if ($Phase -eq 'observe') {
    Add-Type -AssemblyName UIAutomationClient
    Add-Type -AssemblyName UIAutomationTypes
    $root = [System.Windows.Automation.AutomationElement]::RootElement
    $windows = @($root.FindAll([System.Windows.Automation.TreeScope]::Children,[System.Windows.Automation.Condition]::TrueCondition) | Where-Object { $_.Current.Name -like 'AI-Collab-Monitor*' })
    if ($windows.Count -ne 1) { throw "Expected one monitor window, observed $($windows.Count)." }
    $win = $windows[0]
    $records = @()
    foreach ($el in $win.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition)) {
        $pattern = $null
        $text = $null
        if ($el.TryGetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern,[ref]$pattern)) { $text = $pattern.DocumentRange.GetText(-1) }
        if ($text -or $el.Current.ControlType -eq [System.Windows.Automation.ControlType]::Document) {
            $r = $el.Current.BoundingRectangle
            $records += [pscustomobject]@{Name=$el.Current.Name; Type=$el.Current.ControlType.ProgrammaticName; X=$r.X; Y=$r.Y; Width=$r.Width; Height=$r.Height; Offscreen=$el.Current.IsOffscreen; Text=$text}
        }
    }
    $result = [ordered]@{ObservedUtc=[DateTime]::UtcNow.ToString('o'); WindowTitle=$win.Current.Name; WindowHandle=$win.Current.NativeWindowHandle; Pid=$win.Current.ProcessId; Panes=$records}
    Save-Json 'pane-uia-evidence.json' $result
    $result | ConvertTo-Json -Depth 8
}
if ($Phase -eq 'finish') {
    $beforeHash = @($actors | ForEach-Object { [pscustomobject]@{Actor=$_; Hash=(Get-FileHash -LiteralPath (Join-Path $target ('logs\' + $_ + '.log')) -Algorithm SHA256).Hash} })
    Save-Json 'logs-before-reset.json' $beforeHash
    Invoke-MonitorScript 'stop-monitor.ps1' 'stop-result.json'
    if ((Get-Content -LiteralPath (Join-Path $evidence 'stop-result.json') -Raw | ConvertFrom-Json).ExitCode -ne 0) { throw 'Stop not verified; reset not attempted.' }
    $after = Get-ScopedProcessSnapshot
    Save-Json 'processes-after-stop.json' $after
    $before = Get-Content -LiteralPath (Join-Path $evidence 'processes-before.json') -Raw | ConvertFrom-Json
    # The acceptance runner shell itself ends between phases and is not a persistent app session.
    $persistent = @($before | Where-Object { $_.Name -in @('claude','codex','WindowsTerminal','OpenConsole','powershell') })
    $comparison = @($persistent | ForEach-Object {
        $b = $_
        $alive = @($after | Where-Object { $_.Pid -eq $b.Pid -and ([DateTimeOffset]$_.StartedUtc) -eq ([DateTimeOffset]$b.StartedUtc) -and $_.Name -eq $b.Name }).Count -eq 1
        [pscustomobject]@{Name=$b.Name; Pid=$b.Pid; SameProcessAlive=$alive}
    })
    Save-Json 'unrelated-process-survival.json' $comparison
    Invoke-MonitorScript 'reset-monitor.ps1' 'reset-result.json'
    if ((Get-Content -LiteralPath (Join-Path $evidence 'reset-result.json') -Raw | ConvertFrom-Json).ExitCode -ne 0) { throw 'Reset failed.' }
    $archives = @(Get-ChildItem -LiteralPath (Join-Path $target 'archive') -Directory)
    if ($archives.Count -ne 1) { throw 'Unexpected archive count for first acceptance.' }
    $checks = @($actors | ForEach-Object {
        $actor = $_
        $archiveFile = Join-Path $archives[0].FullName ($actor + '.log')
        $expected = ($beforeHash | Where-Object { $_.Actor -eq $actor }).Hash
        [pscustomobject]@{Actor=$actor; ArchivedPath=$archiveFile; ArchivedHashMatches=((Get-FileHash -LiteralPath $archiveFile -Algorithm SHA256).Hash -eq $expected); NewLogBytes=(Get-Item -LiteralPath (Join-Path $target ('logs\' + $actor + '.log'))).Length}
    })
    $task = Get-Content -LiteralPath (Join-Path $evidence 'task-before.json') -Raw | ConvertFrom-Json
    $result = [ordered]@{Logs=$checks; TaskPreserved=((Get-FileHash -LiteralPath $task.Path -Algorithm SHA256).Hash -eq $task.Hash); Unrelated=$comparison}
    Save-Json 'reset-verification.json' $result
    $result | ConvertTo-Json -Depth 8
}
