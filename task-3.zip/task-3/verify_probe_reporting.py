from pathlib import Path
import contextlib,importlib.util,io,json,sys,types

root=Path(r'C:\Users\ryant\Documents\Codex\2026-10-05\task-2')
here=Path(__file__).resolve().parent
for relative in ('scripts/verify_installed_candidate_source.py','scripts/current_acceptance_report.py','scripts/package_source.py'):
    compile((root/relative).read_text(encoding='utf-8'),str(root/relative),'exec')
spec=importlib.util.spec_from_file_location('probe_checks',root/'scripts/verify_installed_candidate_source.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.importlib.import_module=lambda name:types.SimpleNamespace(__file__=str(here/'repair_delivery.py'))
sys.argv=['probe','--output',str(here/'probe-intentional-failure.json')]
with contextlib.redirect_stdout(io.StringIO()):
    code=module.main()
result=json.loads((here/'probe-intentional-failure.json').read_text(encoding='utf-8'))
assert code==1 and result['status']=='FAIL'
assert result['error_type']=='AssertionError' and not result['resolved_path_match']
assert result['actual_module_origin']==str(here/'repair_delivery.py')
assert result['hash_checks']==[] and result['runtime_verified'] is False
assert result['gui_started'] is False and result['backend_started'] is False
print(json.dumps({'syntax_checks':3,'deliberate_wrong_origin_rejected':True,'failure_json_written':True,'actual_wrong_origin_recorded':True,'runtime_or_gui_started':False,'simulation':'Mock module origin only; not an installed-app result'},indent=2))
