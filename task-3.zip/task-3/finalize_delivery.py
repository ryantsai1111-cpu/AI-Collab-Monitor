from pathlib import Path
import datetime,json,shutil
ROOT=Path(r'C:\Users\ryant\Documents\Codex\2026-10-05\task-2')
HERE=Path(__file__).resolve().parent
probe=json.loads((HERE/'installed-source-verification.json').read_text(encoding='utf-8'))
shutil.copy2(HERE/'installed-source-verification.json',ROOT/'evidence/installed-source-verification.json')

p=ROOT/'scripts/package_source.py'
s=p.read_text(encoding='utf-8').replace("\nfiles.extend((root/'evidence').glob('DELIVERY-AUDIT-*.json'))",'')
p.write_text(s,encoding='utf-8')

p=ROOT/'scripts/current_acceptance_report.py'
s=p.read_text(encoding='utf-8')
needle="(E/'FINAL-ACCEPTANCE-REPORT.md').write_text(report,encoding='utf-8')\nsummary="
insert="""report += '\\nActual module origin: `'+probe.get('actual_module_origin','not recorded')+'`. Resolved actual and expected: `'+probe.get('actual_resolved_path','not recorded')+'` and `'+probe.get('expected_resolved_path','not recorded')+'`. Legacy one-sided path assertion would pass: '+str(probe.get('legacy_path_assertion_would_pass'))+'. This clean process reproduces the original assertion failure because Windows packaged-app path resolution redirects LocalAppData; both resolved paths match. All '+str(len(probe.get('hash_checks',[])))+' explicit source hashes match after hex case normalization. The historical failure remains retained, and no installed runtime was started.\\nAudited source archive: `AI-Collaboration-Workspace-source-audited.zip`; compiled EXEs excluded. Older source archive is preserved as history.\\n'
(E/'FINAL-ACCEPTANCE-REPORT.md').write_text(report,encoding='utf-8')
summary="""
assert needle in s
s=s.replace(needle,insert)
p.write_text(s,encoding='utf-8')

p=ROOT/'docs/REQUIREMENTS.md'
s=p.read_text(encoding='utf-8')
at=s.index('## Baseline provenance')
s=s[:at]+'''## Supplemental installed-source checks (outside criterion counts)

Historical installed-source probe failed its one-sided path assertion; original evidence is retained in `evidence/INSTALLED-SOURCE-PROBE-FAILURE.md`. The corrected clean-process module/hash-only probe PASS is in `evidence/installed-source-verification.json`: exact resolved installed acw origin and 60 synced hashes match. Windows packaged-app path resolution redirects both actual and expected LocalAppData paths to the same LocalCache location. No Core, GUI, backend, EXE, production data or credentials were started/accessed. Installed runtime/default-data requirements remain BLOCKED. Requirement 0 FAIL is not a claim that every historical or supplemental execution passed.

''' +s[at:]
p.write_text(s,encoding='utf-8')

audit_path=ROOT/'evidence/DELIVERY-AUDIT-REPAIRS.json'
audit=json.loads(audit_path.read_text(encoding='utf-8'))
audit['verification_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
audit['clean_probe']={'status':probe['status'],'hash_count':len(probe['hash_checks']),'legacy_path_assertion_would_pass':probe['legacy_path_assertion_would_pass'],'actual_module_origin':probe['actual_module_origin'],'actual_resolved_path':probe['actual_resolved_path'],'expected_resolved_path':probe['expected_resolved_path'],'runtime_verified':False}
audit['verification']={'syntax_checks':3,'mock_wrong_origin_rejected':True,'failure_json_written':True,'live_ui_tests_run':False}
audit['archive']='AI-Collaboration-Workspace-source-audited.zip'
audit['archive_excludes_exe']=True
audit_path.write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(audit['clean_probe'],indent=2))
