from pathlib import Path
import datetime,hashlib,json,shutil
root=Path(r'C:\Users\ryant\Documents\Codex\2026-10-05\task-2')
out=root/'evidence/exe-source-remediation2'
if out.exists():raise SystemExit('Refuse to overwrite an existing remediation backup')
names=['scripts/installer_policy.py','scripts/package_source.py','scripts/Launcher.cs','scripts/launcher.manifest','scripts/build_launcher.ps1','scripts/verify_desktop_launch.ps1','scripts/launch_validation_helpers.ps1','scripts/read_launch_snapshot.py','scripts/launch_observation.py','scripts/run_exe_source_tests.py','tests/test_exe_source_hardening.py','install.ps1','docs/EXE-SOURCE-HARDENING.md','README.md']
rows=[]
for name in names:
    source=root/name;backup=out/'first-draft-source'/name
    backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,backup)
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    assert digest==hashlib.sha256(backup.read_bytes()).hexdigest()
    rows.append({'path':name,'sha256':digest,'bytes':source.stat().st_size,'backup':backup.relative_to(root).as_posix()})
record={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'First-draft source-only backup before B1-B3 remediation; original G8 baseline retained','files':rows,'binary_copied_or_touched':False,'installed_app_modified':False}
(out/'baseline.json').write_text(json.dumps(record,ensure_ascii=True,indent=2),encoding='utf-8')
print(json.dumps({'backup':str(out),'files':len(rows),'hashes_verified':True}))
