from pathlib import Path
import hashlib,json,zipfile
root=Path(r'C:\Users\ryant\Documents\Codex\2026-10-05\task-2')
archive=root/'AI-Collaboration-Workspace-source-audited.zip'
with zipfile.ZipFile(archive) as z:
    names=z.namelist()
    assert len(names)==len(set(names))
    assert not any(n.lower().endswith('.exe') for n in names)
    assert not any(n.startswith('audit-backups/') for n in names)
    assert z.testzip() is None
    manifest=json.loads(z.read('evidence/source-manifest.json'))
    for row in manifest['files']:
        assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256'],row['path']
    for relative in ('docs/PRD.md','docs/REQUIREMENTS.md','scripts/verify_installed_candidate_source.py','evidence/installed-source-verification.json','evidence/INSTALLED-SOURCE-PROBE-FAILURE.md','evidence/acceptance-summary.json','evidence/FINAL-ACCEPTANCE-REPORT.md'):
        assert z.read(relative)==(root/relative).read_bytes()
    assert json.loads(z.read('evidence/acceptance-summary.json'))['historical_installed_source_provenance_probe']['status']=='FAIL'
print(json.dumps({'archive':str(archive),'file_count':len(names),'all_manifest_hashes_verified':len(manifest['files']),'zip_crc':'PASS','compiled_exe_count':0,'duplicate_entries':0,'current_probe_and_historical_failure_included':True,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
