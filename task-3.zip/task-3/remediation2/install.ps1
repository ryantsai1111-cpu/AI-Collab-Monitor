[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='High')]
param(
    [Parameter(Mandatory=$true)][string]$Destination,
    [Parameter(Mandatory=$true)][string]$ExpectedResolvedDestination,
    [Parameter(Mandatory=$true)][string]$ExpectedUserProfile,
    [Parameter(Mandatory=$true)][string]$BuildManifest,
    [string]$Python='C:\Users\ryant\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\pythonw.exe',
    [switch]$ResumePartial,
    [switch]$Execute
)
# DEFAULT: read-only preflight plan. -Execute is for a separately approved future
# fresh deployment. A command-line flag is not proof of user authorization.
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'scripts\ascii_json_helpers.ps1')
$source=[IO.Path]::GetFullPath($PSScriptRoot)
$target=[IO.Path]::GetFullPath($Destination)
$profileObserved=[Environment]::GetFolderPath('UserProfile')
if ($Destination -notmatch '^(?:[A-Za-z]:[\\/]|\\\\[^\\]+\\[^\\]+)' -or $ExpectedResolvedDestination -notmatch '^(?:[A-Za-z]:[\\/]|\\\\[^\\]+\\[^\\]+)') { throw 'Fully qualified explicit destinations required; drive-relative paths are rejected' }
if (![string]::Equals([IO.Path]::GetFullPath($profileObserved),[IO.Path]::GetFullPath($ExpectedUserProfile),[StringComparison]::OrdinalIgnoreCase)) { throw 'Execution profile differs from intended user; no deployment' }
$profilePrefix=[IO.Path]::GetFullPath($ExpectedUserProfile).TrimEnd('\')+'\'
if (!$target.StartsWith($profilePrefix,[StringComparison]::OrdinalIgnoreCase)) { throw 'Destination must remain within the explicitly intended user profile' }
$consolePython=Join-Path (Split-Path -Parent $Python) 'python.exe'
if (!(Test-Path -LiteralPath $consolePython -PathType Leaf)) { throw 'Existing companion python.exe required; no installation attempted' }
$shortcuts=@(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'AI Collaboration Workspace.lnk'),
    (Join-Path (Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs') 'AI Collaboration Workspace.lnk')
)
$arguments=@('-X','utf8','-I',(Join-Path $source 'scripts\installer_policy.py'),'--source',$source,
    '--destination',$target,'--expected-resolved',$ExpectedResolvedDestination,'--python',$Python,'--build-manifest',$BuildManifest)
foreach ($shortcutPath in $shortcuts) { $arguments+=@('--shortcut',$shortcutPath) }
if ($ResumePartial) { $arguments+='--resume-partial' }
$output=& $consolePython @arguments
if ($LASTEXITCODE -ne 0) { throw ('Preflight BLOCKED; no writes: '+($output -join "`n")) }
$plan=ConvertFrom-BoundedPlanJson -Text ($output -join "`n")
if (!$Execute) { ConvertTo-StableAsciiJson -Value $plan; return }
if (!$PSCmdlet.ShouldProcess($target,'Fresh deployment of reviewed manifest; never run the EXE')) { return }
$app=Join-Path $target 'app'
# Recheck all conflicts and hashes immediately before the FIRST write.
if (Test-Path -LiteralPath $app) { throw 'App appeared after preflight; no resume/overwrite' }
foreach ($shortcutPath in $shortcuts) { if (Test-Path -LiteralPath $shortcutPath) { throw 'Shortcut appeared after preflight; no writes' } }
foreach ($entry in $plan.files) {
    if ((Get-FileHash -LiteralPath $entry.source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw ('Source changed: '+$entry.path) }
}
$manifest=[ordered]@{schema=1;app='AI-Collaboration-Workspace';state='INCOMPLETE';created_utc=[DateTime]::UtcNow.ToString('o');
    files=$plan.files;build=$plan.build;paths=$plan.paths;runtime=$plan.runtime;created_shortcuts=@();last_error=$null}
[IO.Directory]::CreateDirectory($app) | Out-Null
$manifestPath=Join-Path $app 'install-manifest.json'
try {
    ConvertTo-StableAsciiJson -Value $manifest | Set-Content -LiteralPath $manifestPath -Encoding UTF8
    foreach ($entry in $plan.files) {
        $destinationFile=[IO.Path]::GetFullPath((Join-Path $app $entry.path))
        if (!$destinationFile.StartsWith($app+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Manifest target escapes app' }
        [IO.Directory]::CreateDirectory((Split-Path -Parent $destinationFile)) | Out-Null
        Copy-Item -LiteralPath $entry.source -Destination $destinationFile
        if ((Get-FileHash -LiteralPath $destinationFile -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw ('Copy hash mismatch: '+$entry.path) }
    }
    [IO.File]::WriteAllText((Join-Path $app 'python-path.txt'),$Python)
    $ws=New-Object -ComObject WScript.Shell
    foreach ($shortcutPath in $shortcuts) {
        if (Test-Path -LiteralPath $shortcutPath) { throw 'Shortcut appeared; no overwrite' }
        $shortcut=$ws.CreateShortcut($shortcutPath)
        $shortcut.TargetPath=Join-Path $app 'AI Collaboration Workspace.exe'
        $shortcut.WorkingDirectory=$app; $shortcut.Description='AI Collaboration Workspace'
        $shortcut.Save(); $manifest.created_shortcuts+=@($shortcutPath)
        ConvertTo-StableAsciiJson -Value $manifest | Set-Content -LiteralPath $manifestPath -Encoding UTF8
    }
    $manifest.state='COMPLETED'
    ConvertTo-StableAsciiJson -Value $manifest | Set-Content -LiteralPath $manifestPath -Encoding UTF8
} catch {
    $manifest.state='INCOMPLETE';$manifest.last_error=$_.Exception.Message
    ConvertTo-StableAsciiJson -Value $manifest | Set-Content -LiteralPath $manifestPath -Encoding UTF8
    throw  # No automatic deletion, retry, restore or partial resume.
}
ConvertTo-StableAsciiJson -Value $manifest
