from pathlib import Path
import datetime,difflib,hashlib,json,shutil
root=Path(r'C:\Users\ryant\Documents\Codex\2026-10-05\task-2')
stage=Path(__file__).resolve().parent/'remediation2'
out=root/'evidence/exe-source-remediation2'
baseline=json.loads((out/'baseline.json').read_text(encoding='utf-8'))
original={row['path']:row for row in baseline['files']}
names=['scripts/installer_policy.py','scripts/package_context.py','scripts/ascii_json_helpers.ps1','scripts/package_source.py',
       'scripts/build_launcher.ps1','scripts/verify_desktop_launch.ps1','scripts/launch_validation_helpers.ps1',
       'scripts/read_launch_snapshot.py','scripts/launch_observation.py','scripts/run_exe_source_tests.py',
       'tests/test_exe_source_hardening.py','install.ps1','docs/EXE-SOURCE-HARDENING.md','README.md']
for relative,row in original.items():
    assert hashlib.sha256((root/relative).read_bytes()).hexdigest()==row['sha256'],'Source changed after backup: '+relative
for relative in names:
    if relative not in original:assert not (root/relative).exists(),'New file already exists: '+relative
    assert (stage/relative).is_file()
    if relative.endswith('.py'):compile((stage/relative).read_text(encoding='utf-8'),relative,'exec')
diff=[];rows=[]
for relative in names:
    before=(root/relative).read_text(encoding='utf-8') if relative in original else ''
    after=(stage/relative).read_text(encoding='utf-8')
    diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='first-draft/'+relative,tofile='second-draft/'+relative))
    (root/relative).parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(stage/relative,root/relative)
    digest=hashlib.sha256((root/relative).read_bytes()).hexdigest()
    assert digest==hashlib.sha256((stage/relative).read_bytes()).hexdigest()
    rows.append({'path':relative,'sha256':digest,'bytes':(root/relative).stat().st_size,'first_draft_sha256':original.get(relative,{}).get('sha256'),'verified_equal_to_tested_stage':True})
(out/'source.diff').write_text(''.join(diff),encoding='utf-8')
verification=[]
for folder in sorted((stage/'evidence/exe-source-remediation2').glob('verification-*')):
    destination=out/('stage-'+folder.name)
    assert not destination.exists();shutil.copytree(folder,destination)
    record=json.loads((destination/'offline-result.json').read_text(encoding='utf-8'))
    verification.append({'stage_result':record,'copied_to':destination.relative_to(root).as_posix()})
record={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SOURCE_ONLY_REVIEW_READY',
        'files':rows,'verification':verification,'diff':'evidence/exe-source-remediation2/source.diff',
        'binary_copied_rebuilt_executed':False,'installed_app_or_shortcuts_modified':False,'claude_called':False,
        'limits':['Staging pure/mock tests and PS AST parser; deployed source hashes equal tested bytes.',
                  'No actual package identity API probe or installer/planner/deployment/EXE launch.',
                  'Actual SDK source junction is not traversed or flattened; vendor internal read denied. Dependency layout is not runtime-certified.',
                  'C# unchanged and never compiled; no antivirus/provider clearance or Final acceptance.']}
(out/'changed-source-manifest.json').write_text(json.dumps(record,ensure_ascii=True,indent=2),encoding='utf-8')
report='''# B1–B3 second draft — SOURCE ONLY REVIEW READY

First draft backup/hash: baseline.json and first-draft-source/. Original G8 baseline and Claude request-changes report preserved. Fourteen text source/document/test files changed/added; installed app, shortcuts, binaries and first-round evidence untouched. No source ZIP regeneration.

Changes: all traversed source nodes/ancestors checked by lstat for symlink/reparse; explicit excluded reasons and UNKNOWN necessity refusal; full eligible-source inventories matched to manifest, required Qt/Shiboken entrypoints/distribution metadata and pinned SDK declared exports checked. No actual dependencies prepared/flattened/copied. vendor/bin or unreviewed resources remain fail-closed.

Launch observation: bounded ASCII JSON stdin preserves quoted CommandLine. Exact isolated data and entrypoint arguments are recorded separately from production-data access UNKNOWN. SQLite/JSON errors remain UNKNOWN with original component/type/message. Finally only requests normal close after decoded argv and unchanged PID/birth/CommandLine confirm ownership; ambiguous/error cases do not kill or close unrelated processes. Preflight refusal is BLOCKED_PREFLIGHT.

Package context: readonly kernel32 API source plus resolve/expected-alias agreement; PACKAGED/UNKNOWN/mismatch refuse. Return-code mocks only, not real environment certification. UNPACKAGED does not exclude all filesystem virtualization. Build source: /noconfig, explicit references, attempted-before-Start and redirected stdout/stderr/native failure. No compiler invocation.

Validation: final staging run 23/23 PASS, 0 fail/error/skip. Trusted PS parser (5 source scripts), pure helpers and Windows in-memory argv oracle only; no installer/build/launch entry script was invoked. Changed target source hashes equal tested stage bytes. Earlier staging 22/22 result retained. See stage-verification-* directories for named cases and evidence boundaries.

Remaining: official Claude re-review belongs to parent thread; no Claude call made here. Actual vendor/dependency inventory/layout, process-package identity/virtualization integration, C# compile/runtime, deployment, EXE startup, human-context shortcut and antivirus acceptance remain unverified. Approval for any execution is separate; mock/PASS does not waive these gates.
'''
(out/'STATUS.md').write_text(report,encoding='utf-8')
print(json.dumps({'status':record['status'],'changed_text_files':len(rows),'diff':str(out/'source.diff'),'final_staging_tests':verification[-1]['stage_result']['tests'],'all_hashes_equal_tested_stage':True,'binary_touched':False,'installed_app_modified':False},indent=2))
