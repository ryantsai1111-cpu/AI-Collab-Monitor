from pathlib import Path
import datetime,json,shutil

ROOT=Path(r'C:\Users\ryant\Documents\Codex\2026-10-05\task-2')
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
BACKUP=ROOT/'audit-backups'/stamp
targets=['scripts/verify_installed_candidate_source.py','scripts/current_acceptance_report.py','scripts/package_source.py','evidence/acceptance-summary.json','evidence/requirement-coverage.json','evidence/FINAL-ACCEPTANCE-REPORT.md','evidence/CONTINUATION-CHECKPOINT.md','evidence/CONTINUATION-CHECKPOINT.json','docs/REQUIREMENTS.md','evidence/source-manifest.json']
for rel in targets:
    src=ROOT/rel
    if src.exists():
        dest=BACKUP/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)

probe='''"""Check installed acw module origin and synced source hashes only; no GUI/Core/backend."""
from pathlib import Path
import argparse,datetime,hashlib,importlib,json,sys,traceback

ROOT=Path(__file__).resolve().parents[1]
APP=Path(r'C:\\Users\\ryant\\AppData\\Local\\AI-Collaboration-Workspace\\app')

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=ROOT/'evidence/installed-source-verification.json')
    args=parser.parse_args()
    report={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'status':'FAIL','scope':'Installed acw module origin and explicit synced source hashes only',
            'gui_started':False,'backend_started':False,'exe_executed':False,
            'runtime_verified':False,'user_data_accessed':False,'hash_checks':[],
            'python_executable':sys.executable,'acw_preloaded':'acw' in sys.modules}
    try:
        # Same precedence as run.py: installed APP, then APP/vendor.
        sys.path[:0]=[str(APP),str(APP/'vendor')]
        report['search_prefix']=sys.path[:2]
        expected=APP/'acw/__init__.py'
        report['expected_module_path']=str(expected)
        report['expected_resolved_path']=str(expected.resolve(strict=True))
        acw=importlib.import_module('acw')
        actual=Path(acw.__file__)
        report['actual_module_origin']=str(actual)
        report['actual_resolved_path']=str(actual.resolve(strict=True))
        report['legacy_path_assertion_would_pass']=actual.resolve(strict=True)==expected
        report['resolved_path_match']=actual.resolve(strict=True)==expected.resolve(strict=True)
        if not report['resolved_path_match']:
            raise AssertionError('Installed acw resolved module origin does not match expected installed file')
        sync=json.loads((ROOT/'evidence/installed-source-sync.json').read_text(encoding='utf-8-sig'))
        for row in sync['files']:
            relative=Path(row['path'])
            if relative.is_absolute() or '..' in relative.parts:
                raise ValueError('Invalid synced relative source path')
            source=APP/relative
            if not source.resolve(strict=True).is_relative_to(APP.resolve(strict=True)):
                raise ValueError('Synced source resolves outside installed APP')
            actual_hash=hashlib.sha256(source.read_bytes()).hexdigest()
            expected_hash=row['installed_sha256'].lower()
            report['hash_checks'].append({'path':row['path'],'actual_sha256':actual_hash,
                                         'expected_sha256':expected_hash,'matched':actual_hash==expected_hash})
        mismatches=[r['path'] for r in report['hash_checks'] if not r['matched']]
        if mismatches:
            raise AssertionError('Installed source hash mismatch: '+', '.join(mismatches))
        report['status']='PASS'
        report['reason']='Exact resolved installed module origin and all explicit synced source hashes matched; runtime/UI not tested'
    except Exception as exc:
        report['error_type']=type(exc).__name__
        report['reason']=str(exc)
        report['traceback']=traceback.format_exc()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if report['status']=='PASS' else 1

if __name__=='__main__':
    sys.exit(main())
'''
(ROOT/'scripts/verify_installed_candidate_source.py').write_text(probe,encoding='utf-8')

package=ROOT/'scripts/package_source.py'
s=package.read_text(encoding='utf-8').replace(", 'AI Collaboration Workspace.exe'",'').replace(",'AI Collaboration Workspace.exe'",'')
s=s.replace("'release':'1.0.0-candidate'", "'release':'1.0.0-candidate','compiled_executables_included':False")
s=s.replace("archive=root/'AI-Collaboration-Workspace-source.zip'", "archive=root/'AI-Collaboration-Workspace-source-audited.zip'")
s=s.replace('files=sorted(set(files))',"files=sorted(set(files))\nassert all(p.suffix.lower() != '.exe' for p in files)\nfiles.extend((root/'evidence').glob('DELIVERY-AUDIT-*.json'))")
package.write_text(s,encoding='utf-8')

generator=ROOT/'scripts/current_acceptance_report.py'
s=generator.read_text(encoding='utf-8')
s=s.replace('The source ZIP contains the unchanged original unsigned launcher as preserved static provenance; it was not restored/copied to the installed app or executed again.', 'The audited source ZIP excludes compiled executables. The older ZIP is retained as historical evidence and is not the current audited deliverable. No launcher was restored/copied or executed again.')
start=s.index("if (E/'INSTALLED-SOURCE-PROBE-FAILURE.md').exists():")
end=s.index("summary={'created_utc'",start)
s=s[:start]+'''probe_path=E/'installed-source-verification.json'
probe=json.loads(probe_path.read_text(encoding='utf-8')) if probe_path.exists() else {'status':'NOT RUN','runtime_verified':False}
report += '\\n## Installed-source provenance probe (separate from requirement counts)\\n\\nHistorical probe: **FAIL** at the path assertion; actual origin was not captured. `INSTALLED-SOURCE-PROBE-FAILURE.md` is preserved. Current restricted probe: **'+probe['status']+'**; module origin and explicit synced source hashes only, no Core/GUI/backend/EXE startup. Runtime remains unverified; installed startup/default-data criteria stay BLOCKED. See `installed-source-verification.json`. Requirement 0 FAIL does not mean all historical or supplemental executions passed.\\n'
(E/'FINAL-ACCEPTANCE-REPORT.md').write_text(report,encoding='utf-8')
''' + s[end:]
start=s.index("if (E/'INSTALLED-SOURCE-PROBE-FAILURE.md').exists():")
end=s.index('print(json.dumps(',start)
s=s[:start]+'''summary['requirements_scope']='653 evidence-gated criteria; not 653 native E2E checks; supplemental probe results are separate'
summary['installed_source_provenance_probe']=probe
summary['historical_installed_source_provenance_probe']={'status':'FAIL','evidence':'evidence/INSTALLED-SOURCE-PROBE-FAILURE.md','cause':'Original path assertion failed, origin not captured','runtime_verified':False}
(E/'acceptance-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
''' + s[end:]
s=s.replace("'Visible Qt suite now 41 PASS with preserved historical failed runs'", "'Visible Qt suite now 50 PASS with preserved historical failed runs'")
generator.write_text(s,encoding='utf-8')

coverage=ROOT/'evidence/requirement-coverage.json'
c=json.loads(coverage.read_text(encoding='utf-8'))
ui=json.loads((ROOT/'evidence/ui-acceptance/result.json').read_text(encoding='utf-8'))
changed=0
for criterion in c['criteria']:
    for ev in criterion.get('evidence',[]):
        if ev.get('path')=='evidence/ui-acceptance/result.json' and '13 executed, 12 pass, 1 fail' in ev.get('scope',''):
            ev['previous_scope']=ev['scope']
            ev['scope']=f"Current visible isolated Qt result: {ui['tests']} PASS, {ui['failures']} FAIL, {ui['errors']} ERROR; explicitly synthetic transports; historical initial 13-case run retained separately"
            changed+=1
c['continuation_checkpoint']['superseded']=True
c['continuation_checkpoint']['current_reconciliation']='184 independent: 182 PASS / 2 BLOCKED; original checkpoint retained as history'
c['final_gate']['resolved_blockers']=[v.replace('now 41 PASS','now 50 PASS') for v in c['final_gate']['resolved_blockers']]
coverage.write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf-8')

checkpoint=ROOT/'evidence/CONTINUATION-CHECKPOINT.md'
old=checkpoint.read_text(encoding='utf-8')
checkpoint.write_text('> Historical checkpoint (04:59 UTC), superseded by FINAL-ACCEPTANCE-REPORT.md and acceptance-summary.json. Current: 653 criteria = 589 PASS / 0 FAIL / 60 BLOCKED / 4 UNSUPPORTED / 0 PENDING; original 184 independent = 182 PASS / 2 BLOCKED. Qt50 PASS; widget25 overlap; two-agent16 PASS; native-history5 PASS. Original checkpoint text is retained below. Installed runtime remains unverified; supplemental probe results are separate from criterion counts.\n\n'+old,encoding='utf-8')
jpath=ROOT/'evidence/CONTINUATION-CHECKPOINT.json'
j=json.loads(jpath.read_text(encoding='utf-8'));j['historical_checkpoint']=True;j['superseded_by']=['evidence/FINAL-ACCEPTANCE-REPORT.md','evidence/acceptance-summary.json'];j['current_criterion_counts']=c['status_counts'];j['current_independent_baseline']={'total':184,'PASS':182,'BLOCKED':2}
jpath.write_text(json.dumps(j,ensure_ascii=False,indent=2),encoding='utf-8')

audit={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'backup':str(BACKUP),'backed_up_files':targets,'coverage_stale_scopes_corrected':changed,'compiled_exe_touched':False,'historical_probe_failure_preserved':True}
(ROOT/'evidence/DELIVERY-AUDIT-REPAIRS.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
print(json.dumps(audit,indent=2))
