import unittest
class Fixture(unittest.TestCase):
    def test_sum(self): self.assertEqual(2 + 2, 4)
    def test_string(self): self.assertEqual('acw'.upper(), 'ACW')
    @unittest.skip('deliberate fixture skip')
    def test_skipped(self): pass
