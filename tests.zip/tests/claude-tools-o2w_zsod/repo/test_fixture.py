import unittest
from fixture import add
class TestFixture(unittest.TestCase):
 def test_add(self): self.assertEqual(add(2,3),5)
