param([switch]$ResumePartial, [string]$Destination = (Join-Path $env:LOCALAPPDATA 'AI-Collaboration-Workspace'), [string]$Python = 'C:\Users\ryant\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\pythonw.exe')
$ErrorActionPreference = 'Stop'
$source = [IO.Path]::GetFullPath($PSScriptRoot)
$target = [IO.Path]::GetFullPath($Destination)
$expected = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'AI-Collaboration-Workspace'))
if ($target -ne $expected) { throw 'Installer only targets the dedicated per-user application directory.' }
if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw 'Existing Python runtime missing; no system installation is attempted.' }
$app = Join-Path $target 'app'
if (Test-Path -LiteralPath $app) {
    if (-not $ResumePartial) { throw 'Application already exists; use a reviewed update/partial-resume procedure.' }
    if (Test-Path -LiteralPath (Join-Path $app 'AI Collaboration Workspace.exe')) { throw 'Partial resume never overwrites an executable installation.' }
    $partialCore = Join-Path $app 'acw\core.py'
    $sourceCore = Join-Path $source 'acw\core.py'
    if (-not (Test-Path -LiteralPath $partialCore) -or (Get-FileHash -LiteralPath $partialCore).Hash -ne (Get-FileHash -LiteralPath $sourceCore).Hash) { throw 'Partial directory does not match this reviewed source.' }
}
[IO.Directory]::CreateDirectory($app) | Out-Null
foreach ($name in @('acw','vendor','docs','scripts','evidence','run.py','README.md','requirements.txt')) {
    $item=Join-Path $source $name
    if (Test-Path -LiteralPath $item) { Copy-Item -LiteralPath $item -Destination $app -Recurse -Force }
}
# Ship test source only; live acceptance repositories/datasets are not application files.
$testsTarget = Join-Path $app 'tests'
[IO.Directory]::CreateDirectory($testsTarget) | Out-Null
Get-ChildItem -LiteralPath (Join-Path $source 'tests') -Filter '*.py' -File | Copy-Item -Destination $testsTarget -Force
# Copy the official session helper and installed runtime dependencies, excluding
# the package-manager download cache. No package installation or network here.
$sdkSource = Join-Path $source 'tools\claude-session-sdk'
if (Test-Path -LiteralPath $sdkSource -PathType Container) {
    $sdkTarget = Join-Path $app 'tools\claude-session-sdk'
    [IO.Directory]::CreateDirectory($sdkTarget) | Out-Null
    foreach ($name in @('package.json','pnpm-lock.yaml','session-helper.mjs')) {
        $item = Join-Path $sdkSource $name
        if (Test-Path -LiteralPath $item) { Copy-Item -LiteralPath $item -Destination $sdkTarget -Recurse -Force }
    }
    $nodeSource = Join-Path $sdkSource 'node_modules'
    $nodeTarget = Join-Path $sdkTarget 'node_modules'
    if (Test-Path -LiteralPath $nodeTarget) {
        $resolvedNodeTarget = [IO.Path]::GetFullPath($nodeTarget)
        if (-not $resolvedNodeTarget.StartsWith($app + [IO.Path]::DirectorySeparatorChar)) { throw 'Partial dependency path escapes app.' }
        if ((Get-Item -LiteralPath $nodeTarget).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Refuse moving a linked partial dependency root.' }
        $quarantine = Join-Path $sdkTarget ('node_modules-incomplete-' + [guid]::NewGuid().ToString('N'))
        Move-Item -LiteralPath $nodeTarget -Destination $quarantine
    }
    $consolePython = Join-Path (Split-Path -Parent $Python) 'python.exe'
    & $consolePython (Join-Path $source 'scripts\copy_node_dependencies.py') $nodeSource $nodeTarget
    if ($LASTEXITCODE -ne 0) { throw 'Official session dependency deployment failed.' }
}
Copy-Item -LiteralPath (Join-Path $source 'AI Collaboration Workspace.exe') -Destination $app
[IO.File]::WriteAllText((Join-Path $app 'python-path.txt'),$Python)
$ws = New-Object -ComObject WScript.Shell
foreach ($dir in @([Environment]::GetFolderPath('Desktop'),(Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs'))) {
    $linkPath=Join-Path $dir 'AI Collaboration Workspace.lnk'
    if (Test-Path -LiteralPath $linkPath) { throw "Shortcut already exists: $linkPath. Not overwritten." }
    $shortcut=$ws.CreateShortcut($linkPath)
    $shortcut.TargetPath=Join-Path $app 'AI Collaboration Workspace.exe'
    $shortcut.WorkingDirectory=$app
    $shortcut.Description='AI Collaboration Workspace - official backend adapters'
    $shortcut.Save()
}
Write-Output $app
