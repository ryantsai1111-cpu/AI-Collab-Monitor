# Compiled EXE launch - exact captured blocker

Command: `& .\scripts\verify_desktop_launch.ps1 -Mode exe`
Execution account: ordinary RYAN-PC\ryant; not administrator.
Target: `C:\Users\ryant\AppData\Local\AI-Collaboration-Workspace\app\AI Collaboration Workspace.exe`
Arguments: `--data-dir "<new isolated tests/desktop-exe-GUID directory>"`.
Invocation: .NET `System.Diagnostics.Process.Start(ProcessStartInfo)` with `UseShellExecute = true`, installed app working directory. The compiled C# launcher normally starts the pre-existing pythonw runtime and run.py. The process-start operation failed before a launcher/window was verified.

Exact tool-captured error (locale decoding loss retained):

```text
ParentContainsErrorRecordException: C:\Users\ryant\Documents\Codex\2026-10-05\task-2\scripts\verify_desktop_launch.ps1:11
Line |
  11 |  $launcher=[Diagnostics.Process]::Start($info)
     |  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     | Exception calling "Start" with "1" argument(s): "An error occurred trying to start process
     | 'C:\Users\ryant\AppData\Local\AI-Collaboration-Workspace\app\AI Collaboration Workspace.exe' with working
     | directory 'C:\Users\ryant\AppData\Local\AI-Collaboration-Workspace\app'. �]���ɮץ]�t�f�r�μ�b���U���n��A�ҥH�@�~�����Q�����C"
```

The localized suffix was rendered with encoding loss. Its meaning was the Windows virus/potentially-unwanted-software start rejection. The underlying NativeErrorCode/HResult was not preserved in this failed shell call; no numeric code is claimed. This was not an automatic approval reviewer denial.

Read-only `Get-MpThreatDetection` filtered ONLY by that exact app executable path returned **no matching detections**. Thus a Defender threat name/ID, SmartScreen involvement, other security provider, and a false-positive diagnosis are **not established**. This is an observed Windows shell/process-start security failure, with exact engine unresolved.

No exclusion, protection disable, unblock, signing-policy change, renamed binary retry, alternate launcher success claim, or shortcut retry to the same blocked target occurred. Current compiled executable SHA-256 previously verified: EF202EE2CAF2171805B21F0C22FAB1069FE1CC92EABE7889ED12A02A8BB39005 (see authoritative installation-verification.json for exact hash). Existing Qt/Python testing is separately scoped and is not compiled-EXE acceptance.

Next permissible path: inspect the security decision in the user's Windows Security/provider UI and review source/build provenance, or produce a normally reviewed packaging build. Any proposed security setting, exclusion, unblock or new installation requires explicit approval; none was performed.

## Subsequent read-only diagnosis

At2026-10-05T04:22:38UTC the installed EXE was absent while the source EXE remained present. No file was restored or replaced. Security Center registers Windows Defender and McAfee; scoped recent Defender1116/1117 events were empty. File disappearance is observed; quarantine/removal cause and responsible provider are unproven. See desktop-security-diagnostics.json and source-launcher-provenance.json. Existing installation-verification.json describes earlier successful file/shortcut verification, not current executable availability.
