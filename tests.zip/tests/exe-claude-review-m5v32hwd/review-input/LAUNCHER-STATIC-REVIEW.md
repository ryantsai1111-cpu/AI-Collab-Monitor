# Static launcher review

Only source and existing file/signature records were inspected. No compilation, executable restore/copy/retry, security setting change or quarantine action occurred.

`scripts/Launcher.cs` reads its adjacent `python-path.txt`, validates the existing configured Python path, then starts adjacent `run.py` without shell execution or a console. Its only recognized optional arguments are `--data-dir` and one path. No network, credential extraction, elevation request, approval bypass or process-tree termination is present in this source. These observations do not prove correspondence between source and binary beyond the existing build provenance, and do not establish a false positive or the binary's runtime safety.

Reliability limitations found statically: config file reads and Path.GetFullPath occur outside the exception handler; custom quoted argument construction needs a future Windows edge-case check for paths ending in a backslash. Neither limitation is established as the security rejection's cause. Source and binary were left unchanged.

The existing csc.exe compiler has a Valid Authenticode signature from Microsoft Windows; details and hash are in `launcher-static-build-chain.json`. It was not executed. Compiler signing is not launcher signing: the source launcher binary remains unsigned.

Windows Defender and McAfee are registered; filtered read-only Defender records did not identify this rejection. The installed launcher is absent. Responsible provider, detection name and removal cause remain unknown.

User-only read route: Windows Security → Protection history → select the event matching the launcher filename and rejection time (approximately 2026-10-05 04:02–04:23 UTC). Record provider, detection name, action, time and path only; do not choose Allow or Restore. Microsoft says threat detail visibility may require administrator permission; this review does not authorize elevation. Official instructions: https://support.microsoft.com/en-us/windows/security/windows-security/protection-history-in-the-windows-security-app . A version-specific McAfee navigation route has not been verified.
