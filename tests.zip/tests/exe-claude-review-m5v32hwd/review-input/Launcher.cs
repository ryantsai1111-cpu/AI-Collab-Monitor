using System;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;
class Launcher {
  [STAThread] static int Main(string[] args) {
    string root=AppDomain.CurrentDomain.BaseDirectory;
    string config=Path.Combine(root,"python-path.txt");
    string python=File.Exists(config)?File.ReadAllText(config).Trim():"";
    if (!File.Exists(python)) { MessageBox.Show("The configured existing Python runtime is unavailable. Re-run install.ps1 or see TROUBLESHOOTING.md.","AI Collaboration Workspace");return 1; }
    string arguments="\""+Path.Combine(root,"run.py")+"\"";
    if(args.Length==2 && args[0]=="--data-dir") arguments+=" --data-dir \""+Path.GetFullPath(args[1])+"\"";
    try { Process.Start(new ProcessStartInfo(python,arguments){WorkingDirectory=root,UseShellExecute=false,CreateNoWindow=true});return 0; }
    catch(Exception e){MessageBox.Show(e.Message,"AI Collaboration Workspace");return 1;}
  }
}
